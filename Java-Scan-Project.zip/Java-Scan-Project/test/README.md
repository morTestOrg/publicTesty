# Sca Goat Small
This repository contains deliberately insecure manifest files with vulnerable 3rd party packages. It is designed for security testing
only.

### WARNING :
* ***It is not designed to be used in any unauthorized activity!***
* ***Utilization of any content of this repository for any sort of hacking is strongly prohibited!***
* ***Any usage of the package provided in this repository or usage of the whole manifest may make your system insecure. 
Please make sure you do not make any harm.***

# Contents

* [Nuget testing manifest | C#](/src/goat-nuget.csproj)
* [Pip testing manifest | Python](/src/requirements.txt)

# Scan Report

### Direct packages (11)
Vulnerabilites | Quantity
---------------|---------------
**High**| 29
***Medium***| 31
*Low*| 0
